/*
Copyright © 2020 Insoft. All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

#ifndef types_h
#define types_h

#include "coreX.h"

#define MAP_WIDTH   32
#define MAP_HEIGHT  22

#define TILE_SIZE   8

#define PLAYER_WIDTH    8
#define PLAYER_HEIGHT   8

#define ENEMY_MOVE_RATE 128
#define TILE_ANIM_RATE  24
#define HOLE_FILL_RATE  32
#define DIG_BRICK_RATE  8
#define HOLE_FILL_TIME  30
#define FRAME_IN_HOLE   32

/// for Direction
#define DIR_LEFT    JOYSTICK_LEFT_MASK
#define DIR_RIGHT   JOYSTICK_RIGHT_MASK
#define DIR_UP      JOYSTICK_UP_MASK
#define DIR_DOWN    JOYSTICK_DOWN_MASK

/// for Area
#define ATTR_BKGND        0
#define ATTR_BRICK        1
#define ATTR_METAL        2
#define ATTR_LADDER       3
#define ATTR_PIPE         4
#define ATTR_WARP         5
#define ATTR_HLADDER      6
#define ATTR_GOLD         7
#define ATTR_BRICKOUT     8







/// Enums & Structs

typedef enum {
    GameStateIdle,
    GameStateStartGame,
    GameStateIntro,
    GameStateGameOver,
    GameStateInPlay,
    GameStateCompleted,
    GameStateGameEnded
} GameState;

typedef enum {
    StateNoMove,
    StateLeft,
    StateRight,
    StateUp,
    StateDown,
    StateFall,
    StateDigLeft,
    StateDigRight
} State;

typedef enum {
    TypePlayer = 0,
    TypeEnemy = 40,
    TypeEOL = 255
} Type;


#pragma pack(push)  /* push current alignment to stack */
#pragma pack(1)     /* set alignment to 1 byte boundary */

typedef struct {
    int columns;
    int rows;
    DATA attr;
    DATA map;
    IMAGE tiles;
} Area;

typedef struct {
    uint8_t x;
    uint8_t y;
} Position;

typedef struct {
    Position position;
    uint8_t fillCount;
} Hole;

typedef struct {
    Type type;
    int8_t lastMove;
    State state;            /// Initial state
    int8_t speedCounter;    /// Enemy only!
    State lastState;        /// Last state initial value
    Position position;      /// Where enemy started
    
    bool fallImmunity;      /// Set to 1 to stop falling, one shot)
    uint8_t fallCount;      /// Set to FrameInHole when fall
    
} Object;

typedef struct {
    uint16_t hi_score;
    uint16_t score;
    uint8_t lives;
    
    uint8_t level;
    
    Object object[16];
    Hole hole[4];
    
    GameState state;
} Game;


#pragma pack(pop)   /* restore original alignment from stack */

typedef Area *AreaRef;
typedef Object * ObjectRef;
typedef Game * GameRef;

#endif /* types_h */
