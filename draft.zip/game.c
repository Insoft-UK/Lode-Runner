/*
Copyright © 2020 Insoft. All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

#include "types.h"

#include "game.h"

#include <unistd.h>
#include <stdlib.h>
#include <strings.h>

static char *__DOCUMENTS_PATH = 0;

static Game game;
static Area area = {
    .columns = MAP_WIDTH,
    .rows = MAP_HEIGHT,
    .map = {
        .bytes = NULL
    },
    .attr = {
        .bytes = NULL
    },
    .tiles = {
        .data = {
            .bytes = NULL
        }
    }
};



//MARK: - Map


uint8_t attrAt(int x, int y) {
    uint8_t *map = area.map.bytes;
    uint8_t *attr = area.attr.bytes;
    

    uint8_t uid = map[y / 8 * area.columns + x / 8];
    uint8_t atr = attr[uid];
    return atr;
}

void setTileAt(int x, int y, uint8_t uid) {
    uint8_t *map = area.map.bytes;
    map[y / 8 * area.columns + x / 8] = uid;
}

void map(void)
{
    int col,row;
    uint8_t *map = area.map.bytes;
    uint8_t *attr = area.attr.bytes;
    
    RECT r = {
        .point = {
            .x = 0, .y = 0
        },
        .size = {
            .w = TILE_SIZE, .h = TILE_SIZE
        }
    };
    
    for (row = 0; row < area.rows; row++) {
        for (col = 0; col < area.columns; col++) {
            uint8_t uid = map[row * area.columns + col];
            uint8_t atr = attr[uid];
            if (atr > ATTR_BRICKOUT) continue;
            if (uid) {
                r.point.x = uid % (area.tiles.size.w / TILE_SIZE) * TILE_SIZE;
                r.point.y = uid / (area.tiles.size.w / TILE_SIZE) * TILE_SIZE;
                
                imageSegmentToLayer2(r, &area.tiles, col * r.size.w, row * r.size.h + 16);
            }
        }
    }
}



//MARK: - Levels

void level(int lev) {
    int col,row;
    uint8_t *map = area.map.bytes;
    uint8_t *attr = area.attr.bytes;
    
    game.level = lev;
    sprintf(mem.ram, "%s/internal/level%02d.dat", __DOCUMENTS_PATH, game.level);
    setBytesWithFileNamed(area.map.bytes, mem.ram);
    
    ObjectRef obj = game.object;
    
    for (row = 0; row < area.rows; row++) {
        for (col = 0; col < area.columns; col++) {
            uint8_t uid = map[row * area.columns + col];
            switch (attr[uid]) {
                case 0x40:
                    obj->type = TypePlayer;
                    obj->position.x = col * 8;
                    obj->position.y = row * 8;
                    obj->lastMove = 0;
                    obj->state = StateNoMove;
                    obj->lastState = obj->state;
                    obj->fallImmunity = false;
                    obj->fallCount = 1;
                    obj++;
                    break;
                    
                case 0x80:
                    obj->type = TypeEnemy;
                    obj->position.x = col * 8;
                    obj->position.y = row * 8;
                    obj->lastMove = 0;
                    obj->state = StateNoMove;
                    obj->lastState = obj->state;
                    obj->fallImmunity = true;
                    obj->fallCount = 1;
                    obj++;
                    break;
                    
                default:
                    break;
            }
            
        }
    }
    
    obj->type = TypeEOL;
}

//MARK: - Setup

void setup(const char *bundlePath, const char *documentsPath) {
    chdir(bundlePath);
    
    if (!__DOCUMENTS_PATH) {
        __DOCUMENTS_PATH = malloc(strlen(documentsPath) + 1);
        strcpy(__DOCUMENTS_PATH, documentsPath);
    }
    
    initCoreX();
    
    char *buf = memory(MEMORY_SIZE - 1024); /// 1K Buffer Memory
    
    // Sprites
    sprintf(buf, "%s/game/uk.insoft/resources/sprites.bmp", __DOCUMENTS_PATH);
    
    if (setSpritePatternWithFileNamed(buf) == false) {
        setSpritePatternWithFileNamed("sprites.bmp");
    }
    
    // Character Set
    sprintf(buf, "%s/game/uk.insoft/resources/charset.pbm", __DOCUMENTS_PATH);
    *(uint16_t *)memory(CHARS) = 0xFD58; /// Use custom character set
    if (setCharacterSetWithFileNamed(buf) == false) {
        setCharacterSetWithFileNamed("charset.pbm");
    }
    
    // Area
    area.map.length = area.columns * area.rows;
    area.map.bytes = bank(5);
    area.attr.bytes = bank(5) + area.map.length;
    
    sprintf(buf, "%s/game/uk.insoft/resources/tiles.bmp", __DOCUMENTS_PATH);
    area.tiles.size = setDataWithImageNamed(&area.tiles.data, buf);
    if (area.tiles.size.w == 0 && area.tiles.size.h == 0) {
        area.tiles.size = setDataWithImageNamed(&area.tiles.data, "tiles.bmp");
    }
    
    sprintf(buf, "%s/game/uk.insoft/resources/attr.dat", __DOCUMENTS_PATH);
    if (setBytesWithFileNamed(area.attr.bytes, buf) == false) {
        setBytesWithFileNamed(area.attr.bytes, "attr.dat");
    }
    
    //*(uint16_t *)memory(CHARS) = 0x3C00;
    
    setLayer2System(true);
    poke(BORDCR, BLACK);
    clearScreen(ATTR(BLACK, BLACK) | BRIGHT);
    clearLayer2Screen(RGB(0, 0, 0));
    
    setSpriteSystem(true, false);
    
    game.state = GameStateInPlay;
    level(1);
    game.lives = 3;
    
   
}

//MARK: - Object

void checkMonster(void) {
    
}

bool checkCollision(int x, int y) {
    for (int i=0; i<10; i++) {
        if (game.object[i].type == TypeEnemy) {
            if (game.object[i].position.x == x && game.object[i].position.y == y) return true;
        }
    }
    return false;
}

void fallTest(ObjectRef obj) {
    uint8_t attr;

    // if it is a pipe/ladder then we don't fall.
    attr = attrAt(obj->position.x, obj->position.y);
    if (attr == ATTR_PIPE || attr == ATTR_LADDER) return;
    
    if (obj->type == TypePlayer) goto notholefall;
    if (attr == ATTR_BRICKOUT) return;
    
notholefall:
    attr = attrAt(obj->position.x, obj->position.y + 8);
    if (attr == ATTR_WARP) goto canfall;
    if (attr == ATTR_LADDER) return;
    if (attr == ATTR_BRICK) return;
    if (attr == ATTR_METAL) return;

canfall:
    // does it collide with an enemy? (if so, you are on top of one and can't fall)
    if (checkCollision(obj->position.x, obj->position.y + 8) == true) return; /// can't fall.
    if (obj->fallImmunity == true) return; /// can't fall if immune.
    
    obj->state = StateFall;
    obj->fallCount = 32;    /// Reset "in hole" counter
}

void getPlayerControl(ObjectRef obj) {
    /// Set direction according to player ctrl
    uint8_t direction = z80_inp(KEMPSTON_JOYSTICK1_PORT);
    
    if (direction & JOYSTICK_LEFT_MASK) {
        obj->state = StateLeft;
    }
    
    if (direction & JOYSTICK_RIGHT_MASK) {
        obj->state = StateRight;
    }
    
    if (direction & JOYSTICK_UP_MASK) {
        obj->state = StateUp;
    }
    
    if (direction & JOYSTICK_DOWN_MASK) {
        obj->state = StateDown;
    }
    
    if (direction & JOYSTICK_BUTTON_A_MASK) {
        obj->state = (obj->lastMove == -1) ? StateDigLeft : StateDigRight;
    }
}

// Check can move Object by offset by X,Y
void checkMoveable(ObjectRef obj, int offsetX, int offsetY) {
    if (offsetX < 0 && obj->position.x == 0) goto rejectmove;
    if (offsetX > 0 && obj->position.x == 256 - 8) goto rejectmove;
    
    uint8_t attr;
    
    if (obj->type == TypePlayer) goto notbrickout;

    attr = attrAt(obj->position.x, obj->position.y);
    if (attr != ATTR_BRICKOUT) goto notbrickout;
    if (offsetX != 0) goto rejectmove;
notbrickout:
    attr = attrAt(obj->position.x + offsetX, obj->position.y + offsetY);
    if (attr == ATTR_BRICK || attr == ATTR_METAL) goto rejectmove;
    return;
rejectmove:
    obj->state = StateNoMove;
}

void checkLadder(ObjectRef obj) {
    uint8_t attr;
    
    attr = attrAt(obj->position.x, obj->position.y);
    if (attr != ATTR_LADDER) goto rejectmove;
    
    attr = attrAt(obj->position.x, obj->position.y - 8);
    if (attr == ATTR_BRICK || attr == ATTR_METAL) goto rejectmove;
    return;
    
rejectmove:
    obj->state = StateNoMove;
}

void checkDigging(ObjectRef obj, int offset) {
    uint8_t attr;
    int x,y;
    
    x = obj->position.x + offset;
    y = obj->position.y + 8;
    
    attr = attrAt(x, y);
    if (attr == ATTR_BRICKOUT) {
        y += 8;
        if (attrAt(x, y) != ATTR_BRICK) {
            goto rejectdig;
        }
    } else if (attr != ATTR_BRICK) {
        goto rejectdig;
    }
    return;
    
rejectdig:
    obj->state = StateNoMove;
}

void valididateMovement(ObjectRef obj) {
    if (obj->state == StateLeft) {
        checkMoveable(obj, -8, 0);
        return;
    }
    
    if (obj->state == StateRight) {
        checkMoveable(obj, 8, 0);
        return;
    }
    
    if (obj->state == StateDown) {
        checkMoveable(obj, 0, 8);
        return;
    }
    
    if (obj->state == StateUp) {
        checkLadder(obj);
        return;
    }
    
    if (obj->state == StateDigLeft) {
        checkDigging(obj, -8);
        return;
    }
    
    if (obj->state == StateDigRight) {
        checkDigging(obj, 8);
        return;
    }
}

int16_t randomNumber(void) {
    return rand() % 0xffff;
    
    /*
    static int16_t seedA = 0;
    static int16_t seedB = 0;
    
    //seedA = ((seedA + 1) & 0xfff) + 0x9327;
    seedA ++;
    seedA &= 0xfff;
    seedA += 0x9327;
    seedB = seedB * 4 + 17;
    
    int16_t value = seedA;
    value ^= (seedB >> 8);
    value += (seedB & 0xff);
    
    return value;
     */
}

void aiDirection(ObjectRef enemy, ObjectRef player) {
    if (randomNumber() & 0x1) goto ai_noupdown;
    // If on the same level, try horizontal.
    if (player->position.y == enemy->position.y) goto ai_noupdown;
    
    if (enemy->position.y > player->position.y) {
        enemy->state = StateUp;
    } else {
        enemy->state = StateDown;
    }
    
    valididateMovement(enemy);
    if (enemy->state != StateNoMove) return;
    
    
ai_noupdown:
    // Check for same movement (3 in 4)
    if (randomNumber() & 0x3) goto ai_samemove;
    
    if (randomNumber() & 0x1) goto ai_hormove;
    enemy->state = StateLeft;
    goto ai_noright;
    
ai_hormove:
    if (enemy->position.x > player->position.x) {
        enemy->state = StateLeft;
    } else {
        enemy->state = StateRight;
    }
    
ai_noright:
    valididateMovement(enemy);
    return;
    
ai_samemove:
    enemy->state = enemy->lastState;
    valididateMovement(enemy);
}

void setDirection(ObjectRef obj) {
    if (obj->type == TypeEnemy) {
        if (attrAt(obj->position.x, obj->position.y) == ATTR_BRICKOUT) return;
        for (int i=0; ; i++) {
            if (game.object[i].type == TypePlayer) {
                aiDirection(obj, &game.object[i]);
                obj->lastState = obj->state;
                return;
            }
        }
    }
    
    getPlayerControl(obj);
    valididateMovement(obj);
    obj->lastState = obj->state;
}

void digBrickOut(ObjectRef obj, int offset) {
    static uint8_t digBrickCount = 0;
    
    digBrickCount += DIG_BRICK_RATE;
    
    int x,y;
    
    x = obj->position.x + offset;
    y = obj->position.y + 8;
    
    if (attrAt(x, y) == ATTR_BRICKOUT) y += 8;
    
    if (digBrickCount == 0) {
        setTileAt(x, y, 81);
        obj->state = StateNoMove;
        return;
    }
    
    setTileAt(x, y, 1 + (digBrickCount >> 6) * 16);
}

void moveObject(ObjectRef obj) {
    if (obj->type == TypePlayer) {
        // Check for collision with gold
        
    } else {
        obj->speedCounter += ENEMY_MOVE_RATE;
        if (obj->speedCounter != 0) return;
        // Collision check for bad guys
    }
    
    State state = obj->state;
    if (state == StateNoMove) fallTest(obj);
    
    state = obj->state;
    
    if (state == StateNoMove) {
        setDirection(obj);
        state = obj->state;
    }
    
    if (state == StateLeft) {
        obj->fallImmunity = false;
        obj->position.x--;
        obj->lastMove = -1;
        if ((obj->position.x & 0x7) == 0) {
            obj->state = StateNoMove;
        }
        return;
    }
    
    if (state == StateRight) {
        obj->fallImmunity = false;
        obj->position.x++;
        obj->lastMove = 1;
        if ((obj->position.x & 0x7) == 0) {
            obj->state = StateNoMove;
        }
        return;
    }
    
    if (state == StateFall) {
        obj->position.y += 2;
        if ((obj->position.y & 0x7) == 0) {
            obj->state = StateNoMove;
        }
        return;
    }
    
    if (state == StateUp) {
        obj->position.y--;
        if ((obj->position.y & 0x7) == 0) {
            obj->state = StateNoMove;
        }
        return;
    }
    
    if (state == StateDown) {
        obj->position.y++;
        if ((obj->position.y & 0x7) == 0) {
            obj->state = StateNoMove;
        }
        return;
    }
    
    if (state == StateDigLeft) {
        digBrickOut(obj, -8);
        return;
    }
    
    if (state == StateDigRight) {
        digBrickOut(obj, 8);
        return;
    }
}

void displayObject(ObjectRef obj) {
    int x,y,patternSlot;
    
    x = obj->position.x - 4; /// Adjust x by sub 4 as our 8 x 8 are offset horizontaly by 4 pixels to the right.
    y = obj->position.y + 16;
    
    patternSlot = (obj->type == TypeEnemy) ? 16 : 0;

    switch (obj->state) {
        case StateUp:
        case StateDown:
            patternSlot += 9 + (obj->position.y >> 4 & 0x01);
            setSpriteAttributesEx(patternSlot, x, y, 0, 0, true);
            break;
    
        case StateFall:
            setSpriteAttributesEx(patternSlot, x, y, 0, 0, true);
            break;
            
        case StateDigLeft:
        case StateDigRight:
            setSpriteAttributesEx(11, x, y, 0, (obj->lastMove < 0) ? NX_MIRROR_X_MASK : 0, true);
            break;
            
        case StateNoMove:
            if (obj->type == TypeEnemy) {
                setSpriteAttributesEx(patternSlot + 2, x, y, 0, 0, true);
            } else {
                if (obj->lastMove == 0) {
                    setSpriteAttributesEx(patternSlot, x, y, 0, 0, true);
                } else {
                    patternSlot += 5 + (obj->position.x >> 2 & 0x03);
                    setSpriteAttributesEx(patternSlot, x, y, 0, (obj->lastMove < 0) ? NX_MIRROR_X_MASK : 0, true);
                }
            }
            break;
            
        case StateLeft:
            if (attrAt(obj->position.x, obj->position.y) == ATTR_PIPE) {
                patternSlot += 3 + (obj->position.x >> 2 & 0x01);
                setSpriteAttributesEx(patternSlot, x, y, 0, NX_MIRROR_X_MASK, true);
            } else {
                patternSlot += 5 + (obj->position.x >> 2 & 0x03);
                setSpriteAttributesEx(patternSlot, x, y, 0, NX_MIRROR_X_MASK, true);
            }
            break;
            
        case StateRight:
            if (attrAt(obj->position.x, obj->position.y) == ATTR_PIPE) {
                patternSlot += 3 + (obj->position.x >> 2 & 0x01);
                setSpriteAttributesEx(patternSlot, x, y, 0, 0, true);
            } else {
                patternSlot += 5 + (obj->position.x >> 2 & 0x03);
                setSpriteAttributesEx(patternSlot, x, y, 0, 0, true);
            }
            break;
    }
}

//MARK: - Loop

void inPlay(void) {
    char *buf = memory(MEMORY_SIZE - 1024); /// 1K Buffer Memory
    
    
    
    drawToLayer2(true);
    
    
    

    clearLayer2Screen(RGB(0, 0, 0));
    
    map();
    
    
   
    for (int i=0; game.object[i].type != TypeEOL && i < 10; i++) {
        moveObject(&game.object[i]);
        setSpriteSlot(i);
        displayObject(&game.object[i]);
    }
    
    
    /// Score
    sprintf(buf, "%06d", game.score);
    drawText(buf, 0, 1, ATTR(WHITE, BLACK) | BRIGHT);
    
    /// Lives
    RECT r = {
        .point = {
            .x = 0,
            .y = 0
        },
        .size = {
            .w = 8,
            .h = 8
        }
    };
    
    for (int i=0; i<game.lives; i++) {
        imageSegmentToLayer2(r, &area.tiles, SCREEN_WIDTH - 8 - i * 8, 8);
    }
    

    
    drawText("000000", 10, 1, ATTR(WHITE, BLACK) | BRIGHT);
    
    /// Level
    sprintf(buf, "L=%02d", game.level);
    drawText(buf, 28, 0, ATTR(BLUE, BLACK) | BRIGHT);
    
    drawText("1UP", 3, 0, ATTR(RED, BLACK) | BRIGHT);
    drawText("HIGH SCORE", 8, 0, ATTR(RED, BLACK) | BRIGHT);
    
   
}

void loop(void) {
    switch (game.state) {
        case GameStateIdle:
            
            break;
            
        case GameStateInPlay:
            inPlay();
            
        default:
            break;
    }
}

#pragma mark - Terminate

void terminate(void) {
    if (__DOCUMENTS_PATH) {
        free(__DOCUMENTS_PATH);
        __DOCUMENTS_PATH = 0;
    }
}


